/**
 * 
 */
package weekendassignment;

/**
 * @author msirohi
 *
 */
public class ProblemTwentySeven {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
